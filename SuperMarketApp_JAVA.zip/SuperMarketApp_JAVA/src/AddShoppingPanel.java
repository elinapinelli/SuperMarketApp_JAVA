import java.awt.*;

import javax.swing.*;

/**
 * Class represents adding items to the shopping list.
 * 
 * Functionalities include:
 * add item.
 * 
 * @author Elina
 * @version 1.0
 * @company Elina's Company
 * @date 2023-11-28
 *
 */

public class AddShoppingPanel extends JPanel {
	public JLabel l_nameofproduct;
	private JLabel l_priceofproduct;
	private JLabel l_typeofproduct;
	private JLabel l_quantityofproduct;
	private JLabel l_bought;
	public JTextField t_nameofproduct;
	public JTextField t_priceofproduct;
	public JTextField t_typeofproduct;
	public JTextField t_quantityofproduct;
	public JComboBox d_bought;
	public JPanel button_panel;
	public JButton b_add;
	public JButton b_back;
	public JLabel l_message;
	
	/**
	 * Adding the item
	 */
	public AddShoppingPanel() {
		setLayout(new GridLayout(12,1));//12 rows , 1 column
		setBackground(Color.decode("#ffeacc"));
		l_nameofproduct=new JLabel("Name of product:");
		l_priceofproduct=new JLabel("Price of product:");
		l_typeofproduct=new JLabel("Type of product:");
		l_quantityofproduct=new JLabel("Quantity of product:");
		l_bought=new JLabel("Bought:");
		l_message = new JLabel("");
		l_message.setForeground(Color.RED);
		
		t_nameofproduct=new JTextField();
		t_nameofproduct.setBackground(Color.decode("#fee2d2"));
		
		t_priceofproduct=new JTextField();
		t_priceofproduct.setBackground(Color.decode("#fee2d2"));
		
		t_typeofproduct=new JTextField();
		t_typeofproduct.setBackground(Color.decode("#fee2d2"));
		
		t_quantityofproduct=new JTextField();
		t_quantityofproduct.setBackground(Color.decode("#fee2d2"));
		
		String[] choices = {"Bought", "Not Bought"};
		d_bought=new JComboBox<>(choices);
		d_bought.setBackground(Color.decode("#fee2d2"));
		
		b_add=new JButton("Add");
		b_add.setBackground(Color.decode("#f9ddb1")); //PAINTS
		b_add.setOpaque(true);
		
		b_back=new JButton("Back");
		b_back.setBackground(Color.decode("#f9ddb1")); //PAINTS
		b_back.setOpaque(true);
		
		button_panel=new JPanel();
		
		button_panel.setLayout(new GridLayout(1,2));//1 row , 2 columns
		button_panel.add(b_add);
		button_panel.add(b_back);
		
		add(l_nameofproduct);
		add(t_nameofproduct);
		
		add(l_priceofproduct);
		add(t_priceofproduct);
		
		add(l_typeofproduct);
		add(t_typeofproduct);
		
		add(l_quantityofproduct);
		add(t_quantityofproduct);
		
		add(l_bought);
		add(d_bought);
		
		add(button_panel);
		
		add(l_message);
		
		
		
	}
	

}
