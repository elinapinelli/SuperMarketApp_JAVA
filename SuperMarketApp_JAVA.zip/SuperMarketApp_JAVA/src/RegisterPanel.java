import java.awt.*;

import javax.swing.*;

/**
 * Class represents the register panel.
 * 
 * @author Elina
 * @version 1.0
 * @company Elina's Company
 * @date 2023-11-23
 *
 */
public class RegisterPanel extends JPanel {
	public JLabel l_username;
	public JLabel l_password;
	public JLabel l_firstname;
	public JLabel l_lastname;
	public JLabel l_email;
	public JTextField t_username;
	public JTextField t_password;
	public JTextField t_firstname;
	public JTextField t_lastname;
	public JTextField t_email;
	public JLabel l_message;
	
	public JPanel button_panel;
	public JButton b_login;
	public JButton b_register;
	
	/**
	 * The user registers in the register panel
	 */
	public RegisterPanel() {
		setLayout(new GridLayout(12,1));//12 rows , 1 column
		setBackground(Color.decode("#ffeacc"));
		l_username=new JLabel("Username:");
		l_password=new JLabel("Password:");
		l_firstname=new JLabel("First Name:");
		l_lastname=new JLabel("Last Name:");
		l_email=new JLabel("Email:");
		
		t_username=new JTextField();
		t_username.setBackground(Color.decode("#fee2d2"));
		
		t_password=new JTextField();
		t_password.setBackground(Color.decode("#fee2d2"));
		
		t_firstname=new JTextField();
		t_firstname.setBackground(Color.decode("#fee2d2"));
		
		t_lastname=new JTextField();
		t_lastname.setBackground(Color.decode("#fee2d2"));
		
		t_email=new JTextField();
		t_email.setBackground(Color.decode("#fee2d2"));
		
		l_message=new JLabel("");
		l_message.setForeground(Color.RED);
		
		button_panel=new JPanel();
		b_login=new JButton("Login");
		b_login.setBackground(Color.decode("#f9ddb1")); //PAINTS
		b_login.setOpaque(true);
		
		b_register=new JButton("Register");
		b_register.setBackground(Color.decode("#f9ddb1")); //PAINTS
		b_register.setOpaque(true);
		
		button_panel.setLayout(new GridLayout(1,2));//1 row , 2 columns
		
		button_panel.add(b_register);
		button_panel.add(b_login);
		
		add(l_username);
		add(t_username);
		add(l_password);
		add(t_password);
		add(l_firstname);
		add(t_firstname);
		add(l_lastname);
		add(t_lastname);
		add(l_email);
		add(t_email);
		add(button_panel);
		add(l_message);
	}

}
