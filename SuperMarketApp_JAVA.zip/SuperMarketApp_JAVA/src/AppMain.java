/**
 * Class represents the main of the app.
 * 
 * @author Elina
 * @version 1.0
 * @company Elina's Company
 * @date 2023-11-23
 *
 */
public class AppMain {

	public static void main(String[] args) {
		

		
		MainAppFrame app=new MainAppFrame();
	}

}

