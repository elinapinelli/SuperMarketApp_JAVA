/**
 *enumurator represents if the user did a correct login.
 * 
 * Enumurator values:
 * WrongPassword,
 * WrongUserName,
 * UserFound.
 * 
 * @author Elina
 * @version 1.0
 * @company Elina's Company
 * @date 2023-12-01
 *
 */
public enum EnumOfLogin {
	WrongPassword,
	WrongUserName,
	UserFound
}
