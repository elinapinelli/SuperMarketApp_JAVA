import java.io.File;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class represents the users list of the app.
 * 
 * @author Elina
 * @version 1.0
 * @company Elina's Company
 * @date 2023-11-25
 *
 */

public class UserList {
	private ArrayList<User> usersList;

	/**
	 *  Constructor that creates an empty user list.
	 */
	public UserList() {
		this.usersList = new  ArrayList<User>();//initialize new empty list
	}
	
	/**
	 * Adding a new user.
	 * 
	 * @param newUser (User)
	 */
	public void addUser(User newUser) {
		usersList.add(newUser);
	}
	
	/**
	 * Adding a new user by data.
	 * 
	 * @param userName (String) represents the user name of the user
	 * @param password (String) represents the password of the user
	 * @param firstName (String) represents the first name of the user
	 * @param lastName (String) represents the last name of the user
	 * @param email (String) represents the email of the user
	 */
	public void addUserByData(String userName, String password, String firstName, String lastName, String email) {
		User newUser = new User(userName, password, firstName, lastName, email);
		usersList.add(newUser);
	}
	
	/**
	 * Display all the users.
	 */
	public void displayUsers() {
		for( int i=0; i<usersList.size(); i++) {
			System.out.println(usersList.get(i).toString());
		}
	}
	/**
	 * Writes the users to a txt file.
	 * 
	 * @param fileName (String)
	 */
	public void toFile(String fileName) {
		try(PrintWriter writer = new PrintWriter(new File(fileName))){
			for(int i=0; i<usersList.size(); i++) {
				writer.println(usersList.get(i).toString());
			}
			
		}catch (FileNotFoundException e) {
            e.printStackTrace(); // Handle the exception appropriately
        }
		
	}
	
	/**
	 * Reads the users from a txt file.
	 * 
	 * @param fileName (String)
	 */
	public void fromFile(String fileName) {
		String line;
		try {
			Scanner sc = new Scanner(new File(fileName));
			while(sc.hasNextLine()) {
				line=sc.nextLine();
				User new_user=new User(line);
				addUser(new_user);
				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
	}
	/**
	 * Checks the usernames and the passwords if match.
	 * 
	 * @param userName (String)
	 * @param password (String)
	 * @return (EnumOfLogin)
	 */
	public EnumOfLogin searchByUserNameAndPassword(String userName, String password) {
		EnumOfLogin enumToReturn=EnumOfLogin.WrongUserName;
		for ( int i=0; i<usersList.size(); i++) {
			if (userName.equals(usersList.get(i).getUserName())) {//check if username is correct
				if(password.equals(usersList.get(i).getPassword())) {//check if password is correct
					return  EnumOfLogin.UserFound;
					
				}
				else {
					return  EnumOfLogin.WrongPassword;
				}
				
			}
		}		
		return enumToReturn;
	}
	
	
	
}
