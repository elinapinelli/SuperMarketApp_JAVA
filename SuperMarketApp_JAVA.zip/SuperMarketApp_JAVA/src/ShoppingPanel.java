import java.awt.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.LineBorder;

/**
 * Class represents the shopping panel of the app.
 * 
 * Functionalities include:
 * modify shopping panel,
 * sum of bought items,
 * sum of not bought items
 * 
 * @author Elina
 * @version 1.0
 * @company Elina's Company
 * @date 2023-11-30
 *
 */

public class ShoppingPanel extends JPanel {
	public JPanel display_panel;
	public JPanel button_panel;
	public JButton b_add;
	public JButton b_exit;
	public JPanel search_panel;
	public JTextField t_search;
	public JButton b_search;
	public JPanel sum_panel;
	public JLabel l_sum_bought_1;
	public JLabel l_sum_bought_2;
	public JLabel l_sum_not_bought_1;
	public JLabel l_sum_not_bought_2;
	private ModifyShoppingPanel modify_panel;
	private Container contentPane;
	public JScrollPane s_bar;
	
	/**
	 * Constructor that creates the shopping panel.
	 * 
	 * @param modify_panel (ModifyShoppingPanel)
	 * @param contentPane (Container)
	 */
	public ShoppingPanel(ModifyShoppingPanel modify_panel, Container  contentPane) {
		setLayout(new FlowLayout());//3 rows , 1 column
		setBackground(Color.decode("#ffeacc"));
		display_panel=new JPanel();
//		display_panel.setPreferredSize(new Dimension(410, 150));
		
		//SCROLL BAR
		s_bar =  new JScrollPane(display_panel);
		s_bar.setPreferredSize(new Dimension(750, 150));
		
		this.modify_panel=modify_panel;
		this.contentPane=contentPane;
		button_panel=new JPanel();
		
		search_panel = new JPanel();
		t_search = new JTextField();
		t_search.setBackground(Color.decode("#fee2d2"));
		t_search.setPreferredSize(new Dimension(410, 30));
		
		b_add=new JButton("Add");
		b_add.setBackground(Color.decode("#f9ddb1")); //PAINTS
		b_add.setOpaque(true);
		
		b_exit=new JButton("Exit");
		b_exit.setBackground(Color.decode("#f9ddb1")); //PAINTS
		b_exit.setOpaque(true);
		
		b_search =new JButton();
		b_search.setBackground(Color.decode("#f9ddb1")); //PAINTS
		b_search.setOpaque(true);
		ImageIcon icon = new ImageIcon("search_icon25.png"); //PNG SEARCH ICON
		b_search.setIcon(icon);
		b_search.setPreferredSize(new Dimension(50, 30));
		
		button_panel.setLayout(new GridLayout(1,2));//1 row , 2 columns
		button_panel.add(b_add);
		button_panel.add(b_exit);
		search_panel.setLayout(new FlowLayout());//1 row , 2 columns
		search_panel.add(t_search);
		search_panel.add(b_search);
		
		sum_panel = new JPanel();
		sum_panel.setPreferredSize(new Dimension(600,30));
		sum_panel.setBackground(Color.decode("#ffeacc"));
		LineBorder redBorder = new LineBorder(Color.decode("#ff5f00"), 2);
		sum_panel.setBorder(redBorder);
		l_sum_bought_1 = new JLabel("Sum Of Bought:");
		l_sum_bought_2 = new JLabel("0€");
		l_sum_bought_2.setBackground(Color.decode("#fcfc5c"));
		l_sum_bought_2.setOpaque(true);
		l_sum_not_bought_1 = new JLabel(", Sum Of Not Bought:");
		l_sum_not_bought_2 = new JLabel("0€"); 
		l_sum_not_bought_2.setBackground(Color.decode("#fcfc5c"));
		l_sum_not_bought_2.setOpaque(true);
		

		sum_panel.add(l_sum_bought_1);
		sum_panel.add(l_sum_bought_2);
		sum_panel.add(l_sum_not_bought_1);
		sum_panel.add(l_sum_not_bought_2);
		
		add(sum_panel);
		add(search_panel);
//		add(display_panel);
		add(s_bar);
		add(button_panel);
		
	}
	
	/**
	 * Creates the sum of the bought items of the user that has logged in.
	 * 
	 * @param userList (ArrayList<Shopping>) represents the sum of the not bought items.
	 * @return (double)
	 */
	public double  sum_of_bought(ArrayList<Shopping> userList) {
			
			double suma=0;
			for (int i=0;i<userList.size();i++) {//for each shopping
				if(userList.get(i).isBought()==true) {
					suma=suma+userList.get(i).get_cost();
					
				}
			}
			return suma;
		}
	
	/**
	 * Creates the sum of the not bought items of the user that has logged in.
	 * 
	 * @param userList (ArrayList<Shopping>) represents the sum of the not bought items.
	 * @return (double)
	 */
	public double  sum_of_not_bought(ArrayList<Shopping> userList) {
	
		double suma=0;
		for (int i=0;i<userList.size();i++) {//for each shopping
			if(userList.get(i).isBought()==false) {
				suma=suma+userList.get(i).get_cost();
			}
		}
		return suma;
		
	}
	
	/**
	 * Fill the display panel of the user shopping items.
	 * 
	 * @param userShoppingList (ArrayList<Shopping>)
	 * @param wholeShoppingList (ShoppingList)
	 * @param filename_of_shopping (String)
	 * @param username_logged (String)
	 */
	public void fillDisplayPanel(ArrayList<Shopping> userShoppingList,ShoppingList wholeShoppingList,String  filename_of_shopping,String username_logged) {
		display_panel.removeAll();//I clear the panel
		display_panel.revalidate();
		display_panel.repaint();
		
		if(userShoppingList.size()==0) {
			JLabel l_zero=new JLabel("No Shopping items are added"); 
			display_panel.add(l_zero);
			l_sum_bought_2 .setText("0€");
			l_sum_not_bought_2.setText("0€");
		}
		else {
			l_sum_bought_2.setText(String.valueOf(sum_of_bought(userShoppingList))+"€");
			l_sum_not_bought_2.setText(String.valueOf(sum_of_not_bought(userShoppingList))+"€");
			
//			display_panel.setLayout(new GridLayout(userShoppingList.size()+1,1));
			display_panel.setLayout(new BoxLayout(display_panel, BoxLayout.Y_AXIS));
			JPanel title_panel = new JPanel();//create a panel that represents a row
			title_panel.setLayout(new GridLayout(1,9));
			
			JLabel l_title_row = new JLabel("A/A");
			l_title_row.setHorizontalAlignment(JLabel.CENTER);
			l_title_row.setVerticalAlignment(JLabel.CENTER);
			l_title_row.setBackground(Color.decode("#d24e01"));
			l_title_row.setOpaque(true);
			l_title_row.setForeground(Color.WHITE);
			
			JLabel l_title_nameofproduct = new JLabel("Name");
			l_title_nameofproduct.setHorizontalAlignment(JLabel.CENTER);
			l_title_nameofproduct.setVerticalAlignment(JLabel.CENTER);
			l_title_nameofproduct.setBackground(Color.decode("#d24e01"));
			l_title_nameofproduct.setOpaque(true);
			l_title_nameofproduct.setForeground(Color.WHITE);
			
			JLabel l_title_priceofproduct = new JLabel("Price");
			l_title_priceofproduct.setHorizontalAlignment(JLabel.CENTER);
			l_title_priceofproduct.setVerticalAlignment(JLabel.CENTER);
			l_title_priceofproduct.setBackground(Color.decode("#d24e01"));
			l_title_priceofproduct.setOpaque(true);
			l_title_priceofproduct.setForeground(Color.WHITE);
			
			JLabel l_title_typeofproduct = new JLabel("Type");
			l_title_typeofproduct.setHorizontalAlignment(JLabel.CENTER);
			l_title_typeofproduct.setVerticalAlignment(JLabel.CENTER);
			l_title_typeofproduct.setBackground(Color.decode("#d24e01"));
			l_title_typeofproduct.setOpaque(true);
			l_title_typeofproduct.setForeground(Color.WHITE);
			
			JLabel l_title_quantityofproduct = new JLabel("Quantity");
			l_title_quantityofproduct.setHorizontalAlignment(JLabel.CENTER);
			l_title_quantityofproduct.setVerticalAlignment(JLabel.CENTER);
			l_title_quantityofproduct.setBackground(Color.decode("#d24e01"));
			l_title_quantityofproduct.setOpaque(true);
			l_title_quantityofproduct.setForeground(Color.WHITE);
			
			JLabel l_title_bought=new JLabel("Bought");
			l_title_bought.setHorizontalAlignment(JLabel.CENTER);
			l_title_bought.setVerticalAlignment(JLabel.CENTER);
			l_title_bought.setBackground(Color.decode("#d24e01"));
			l_title_bought.setOpaque(true);
			l_title_bought.setForeground(Color.WHITE);
			
			JLabel l_title_cost=new JLabel("Cost");
			l_title_cost.setHorizontalAlignment(JLabel.CENTER);
			l_title_cost.setVerticalAlignment(JLabel.CENTER);
			l_title_cost.setBackground(Color.decode("#d24e01"));
			l_title_cost.setOpaque(true);
			l_title_cost.setForeground(Color.WHITE);
			
			JLabel l_title_delete=new JLabel("Delete");
			l_title_delete.setHorizontalAlignment(JLabel.CENTER);
			l_title_delete.setVerticalAlignment(JLabel.CENTER);
			l_title_delete.setBackground(Color.decode("#d24e01"));
			l_title_delete.setOpaque(true);
			l_title_delete.setForeground(Color.WHITE);
			
			JLabel l_title_modify=new JLabel("Modify");
			l_title_modify.setHorizontalAlignment(JLabel.CENTER);
			l_title_modify.setVerticalAlignment(JLabel.CENTER);
			l_title_modify.setBackground(Color.decode("#d24e01"));
			l_title_modify.setOpaque(true);
			l_title_modify.setForeground(Color.WHITE);
			
			title_panel.add(l_title_row);
			title_panel.add(l_title_nameofproduct);
			title_panel.add(l_title_priceofproduct);
			title_panel.add(l_title_typeofproduct);
			title_panel.add(l_title_quantityofproduct);
			title_panel.add(l_title_bought);
			title_panel.add(l_title_cost);
			
			title_panel.add(l_title_delete);
			title_panel.add(l_title_modify);
			display_panel.add(title_panel);
			
			for(int i=0;i<userShoppingList.size();i++) {//for each user's shopping
				Shopping temp=userShoppingList.get(i);
				JPanel row_panel = new JPanel();//create a panel that represents a row
				row_panel.setLayout(new GridLayout(1,9));
				
				JLabel l_row = new JLabel(String.valueOf(i+1));
				l_row.setHorizontalAlignment(JLabel.CENTER);
				l_row.setVerticalAlignment(JLabel.CENTER);
				
				JLabel l_nameofproduct = new JLabel(userShoppingList.get(i).getNameofproduct());
				l_nameofproduct.setHorizontalAlignment(JLabel.CENTER);
				l_nameofproduct.setVerticalAlignment(JLabel.CENTER);
				
				JLabel l_priceofproduct = new JLabel(String.valueOf(userShoppingList.get(i).getPriceofproduct())+"€");
				l_priceofproduct.setHorizontalAlignment(JLabel.CENTER);
				l_priceofproduct.setVerticalAlignment(JLabel.CENTER);
				
				JLabel l_typeofproduct = new JLabel(userShoppingList.get(i).getTypeofproduct());
				l_typeofproduct.setHorizontalAlignment(JLabel.CENTER);
				l_typeofproduct.setVerticalAlignment(JLabel.CENTER);
				
				JLabel l_quantityofproduct = new JLabel(String.valueOf(userShoppingList.get(i).getQuantityofproduct()));
				l_quantityofproduct.setHorizontalAlignment(JLabel.CENTER);
				l_quantityofproduct.setVerticalAlignment(JLabel.CENTER);
				
				JLabel l_bought;
				
				if (userShoppingList.get(i).isBought()==true) {
					l_bought = new JLabel("Bought");
				}
				else {
					l_bought = new JLabel("Not Bought");
				}
				l_bought.setHorizontalAlignment(JLabel.CENTER);
				l_bought.setVerticalAlignment(JLabel.CENTER);
				
				JLabel l_cost=new JLabel(String.valueOf(userShoppingList.get(i).get_cost())+"€");
				l_cost.setHorizontalAlignment(JLabel.CENTER);
				l_cost.setVerticalAlignment(JLabel.CENTER);
				
				JButton b_delete = new JButton();
				ImageIcon icon_del = new ImageIcon("delete.png");
				b_delete.setIcon(icon_del);
				
				b_delete.addActionListener(new ActionListener() {
	                @Override
	                public void actionPerformed(ActionEvent e) {
	                	wholeShoppingList.deleteShopping(temp);
	                	wholeShoppingList.toFile(filename_of_shopping);
	                	ArrayList<Shopping> newuserShoppingList=wholeShoppingList.getShoppingByUsername(username_logged);
	                	fillDisplayPanel(newuserShoppingList, wholeShoppingList,filename_of_shopping,username_logged);
	                	
	                	
	                	
	                }
	            });
				
				JButton b_modify = new JButton();
				ImageIcon icon_mod = new ImageIcon("pen.png");
				b_modify.setIcon(icon_mod);
				
				b_modify.addActionListener(new ActionListener() {
	                @Override
	                public void actionPerformed(ActionEvent e) {
	                	
	                	modify_panel.fill_modify_panel(temp);
	                	CardLayout cardLayout = (CardLayout) (contentPane.getLayout());
	                	cardLayout.next(contentPane);//go to add_panel
	                    cardLayout.next(contentPane);//go to modify_panel
//	                    cardLayout.next(contentPane);//go to login_panel
//	                    cardLayout.next(contentPane);//go to shopping_panel
	                	
	                	
	                }
	            });
				
				
				if(i%2==0) {//even rows
					l_row.setBackground(Color.decode("#f9ddb1"));
					l_row.setOpaque(true);
					
					l_nameofproduct.setBackground(Color.decode("#f9ddb1"));
					l_nameofproduct.setOpaque(true);
					
					l_priceofproduct.setBackground(Color.decode("#f9ddb1"));
					l_priceofproduct.setOpaque(true);
					
					l_typeofproduct.setBackground(Color.decode("#f9ddb1"));
					l_typeofproduct.setOpaque(true);
					
					l_quantityofproduct.setBackground(Color.decode("#f9ddb1"));
					l_quantityofproduct.setOpaque(true);
					
					l_bought.setBackground(Color.decode("#f9ddb1"));
					l_bought.setOpaque(true);
					
					l_cost.setBackground(Color.decode("#f9ddb1"));
					l_cost.setOpaque(true);
					
					b_delete.setBackground(Color.decode("#f9ddb1"));
					l_cost.setOpaque(true);
					b_modify.setBackground(Color.decode("#f9ddb1"));
					l_cost.setOpaque(true);
				}
				else {//odd rows
					l_row.setBackground(Color.decode("#f5c776"));
					l_row.setOpaque(true);
					
					l_nameofproduct.setBackground(Color.decode("#f5c776"));
					l_nameofproduct.setOpaque(true);
					
					l_priceofproduct.setBackground(Color.decode("#f5c776"));
					l_priceofproduct.setOpaque(true);
					
					l_typeofproduct.setBackground(Color.decode("#f5c776"));
					l_typeofproduct.setOpaque(true);
					
					l_quantityofproduct.setBackground(Color.decode("#f5c776"));
					l_quantityofproduct.setOpaque(true);
					
					l_bought.setBackground(Color.decode("#f5c776"));
					l_bought.setOpaque(true);
					
					l_cost.setBackground(Color.decode("#f5c776"));
					l_cost.setOpaque(true);
					
					b_delete.setBackground(Color.decode("#f5c776"));
					l_cost.setOpaque(true);
					b_modify.setBackground(Color.decode("#f5c776"));
					l_cost.setOpaque(true);
				}
				
				row_panel.add(l_row);
				row_panel.add(l_nameofproduct);
				row_panel.add(l_priceofproduct);
				row_panel.add(l_typeofproduct);
				row_panel.add(l_quantityofproduct);
				row_panel.add(l_bought);
				row_panel.add(l_cost);
				row_panel.add(b_delete);
				row_panel.add(b_modify);				
				display_panel.add(row_panel);
				
				
			}
			
		}
		
	}
}
