import java.awt.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

/**
 * Class represents the login panel of the app.
 * 
 * @author Elina
 * @version 1.0
 * @company Elina's Company
 * @date 2023-11-27
 *
 */

public class LoginPanel extends JPanel{
	public JLabel l_username;
	public JLabel l_password;
	public JLabel l_message;
	public JTextField t_username;
	JPanel password_panel;
	public JPasswordField  t_password;
	JButton b_reveal_password;
	public JPanel button_panel;
	public JButton b_login;
	public JButton b_register;
	public boolean password_is_hide=true;
	public LoginPanel() {
		
		setLayout(new FlowLayout());//6 rows , 1 column
		setBackground(Color.decode("#ffeacc"));
		l_username=new JLabel("Username:");
		l_password=new JLabel("Password:");
		l_message=new JLabel("");
		l_message.setForeground(Color.RED);
		
		t_username=new JTextField();
		t_username.setBackground(Color.decode("#fee2d2"));
		t_username.setPreferredSize(new Dimension(410, 30));
		
		t_password=new JPasswordField();
		t_password.setBackground(Color.decode("#fee2d2"));
		t_password.setPreferredSize(new Dimension(350, 30));
		
		b_reveal_password=new JButton();
		ImageIcon icon = new ImageIcon("show.png");
		b_reveal_password.setIcon(icon);
		b_reveal_password.setPreferredSize(new Dimension(50, 30));
		b_reveal_password.setBackground(Color.decode("#f9ddb1")); //PAINTS
		b_reveal_password.setOpaque(true);
		password_panel=new JPanel();
		
		password_panel.setLayout(new FlowLayout());
		password_panel.add(t_password);
		password_panel.add(b_reveal_password);
		
		
		button_panel=new JPanel();
		b_login=new JButton("Login");
		b_login.setBackground(Color.decode("#f9ddb1")); //PAINTS
		b_login.setOpaque(true);
		
		b_register=new JButton("Register");
		b_register.setBackground(Color.decode("#f9ddb1")); //PAINTS
		b_register.setOpaque(true);
		
		button_panel.setLayout(new GridLayout(1,2));//1 row , 2 columns
		button_panel.add(b_login);
		button_panel.add(b_register);
		
		add(l_username);
		add(t_username);
		add(l_password);
		add(password_panel);
		add(button_panel);
		add(l_message);
		
		reveal_hide_password();
		
	}
	
	/**
	 * reveal or hide the password
	 */
	public void reveal_hide_password() {
		b_reveal_password.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	ImageIcon showIcon = new ImageIcon("show.png");
                ImageIcon hideIcon = new ImageIcon("hide.png");
                
                if (password_is_hide==true) {
                	b_reveal_password.setIcon(hideIcon);
                	t_password.setEchoChar((char) 0);
                	password_is_hide=false;
                	
                }
                else {
                	b_reveal_password.setIcon(showIcon);
                	t_password.setEchoChar('*');
                	password_is_hide=true;
                }
            }
        });
	}

}
