import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.Collectors;

/**
 * Class represent a list of Shopping.
 * 
 * Functionalities include:
 * display all shoppings,
 * add shopping,
 * write list to file, 
 * read list from file,
 * filter by user name,
 * search the list,
 * delete shopping,
 * modify shopping.
 * 
 * @author Elina
 * @version 1.0
 * @company Elina's Company
 * @date 2023-12-05
 *
 */
public class ShoppingList {
	private ArrayList<Shopping> shoppingList;
	
	/**
	 * Constructor that creates an Array shopping list.
	 */
	public ShoppingList() {
		this.shoppingList = new ArrayList<Shopping>();
		
	}
	
	/**
	 * Adding a new shopping to the shopping list
	 * @param newShopping (Shopping)
	 */
	public void addShopping(Shopping newShopping) {
		shoppingList.add(newShopping);
	}
	 
	/**
	 * Adds a shopping to the shopping list by data.
	 * 
	 * @param nameofproduct (String) represents the name of one product
	 * @param priceofproduct (double) represents the price of one product
	 * @param typeofproduct (String) represents the name of one product
	 * @param quantityofproduct (int) represents the quantity of one product
	 * @param bought (boolean) represents if the user has bought or not bought the item
	 * @param username (String) represents each user that have logged in
	 */
	public void addShoppingByData(String nameofproduct, double priceofproduct, String typeofproduct, int quantityofproduct, boolean bought, String username) {
		Shopping newShopping = new Shopping(nameofproduct, priceofproduct, typeofproduct, quantityofproduct, bought, username);
		shoppingList.add(newShopping);
	}
	
	/**
	 * Display all the shoppings of the user that had logged in
	 */
	public void displayShoppings() {
		for( int i=0; i<shoppingList.size(); i++) {
			System.out.println(shoppingList.get(i).toString());
		}
	}
	
	/**
	 * Writes the shoppings to the txt file
	 * it catches an exception if the file is not found
	 * 
	 * @param fileName (String)
	 */
	public void toFile(String fileName) {
		try(PrintWriter writer = new PrintWriter(new File(fileName))){
			for(int i=0; i<shoppingList.size(); i++) {
				writer.println(shoppingList.get(i).toString());
			}
			
		}catch (FileNotFoundException e) {
            e.printStackTrace(); // Handle the exception appropriately
        }
		
	}
	/**
	 * Reads the shoppings from the txt file
	 * it reads the next line
	 * it catches an exception if the file is not found
	 * 
	 * @param fileName (String)
	 */
	public void fromFile(String fileName) {
		String line;
		try {
			Scanner sc = new Scanner(new File(fileName));
			while(sc.hasNextLine()) {
				line=sc.nextLine();
				Shopping new_shopping=new Shopping(line);
				addShopping(new_shopping);
				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
	}
	
	/**
	 * New Array List that takes the shopping list of each user that have logged in
	 * 
	 * @param username (String)
	 * @return (ArrayList<Shopping>) represents the shopping list of the user.
	 */
	//1)EXAMPLE OF FUNCTIONAL PROGRAMMING CODE.
	public ArrayList<Shopping> getShoppingByUsername(String username) {
		ArrayList<Shopping> newArrayList =(ArrayList<Shopping>) shoppingList.stream()
				.filter(each_shopping -> each_shopping.getUsername().equals(username)).collect(Collectors.toList());
		
		return newArrayList;
	}
	
/**
 * Search the usernames
 * 
 * @param search_string (String)
 * @param username (String)
 * @return (ArrayList<Shopping>)
 */
	
	public ArrayList<Shopping> search(String search_string,String username){
		ArrayList<Shopping> searchList=new ArrayList<Shopping>();
		ArrayList<Shopping> userList=getShoppingByUsername( username);
		for (int i=0;i<userList.size();i++) {//for each shopping
			if(userList.get(i).getNameofproduct().toLowerCase().contains(search_string.toLowerCase())) {//if name contains the search_string
				searchList.add(userList.get(i));//add into the search array the Shopping
			}
			else if(String.valueOf(userList.get(i).getPriceofproduct()).toLowerCase().contains(search_string.toLowerCase())) {//if name contains the search_string
				searchList.add(userList.get(i));//add into the search array the Shopping
			}
			else if(String.valueOf(userList.get(i).getQuantityofproduct()).toLowerCase().contains(search_string.toLowerCase())) {//if name contains the search_string
				searchList.add(userList.get(i));//add into the search array the Shopping
			}
			else if(userList.get(i).getTypeofproduct().toLowerCase().contains(search_string.toLowerCase())) {//if name contains the search_string
				searchList.add(userList.get(i));//add into the search array the Shopping
			}
			else if(userList.get(i).isBought()==true && "Bought".toLowerCase().contains(search_string.toLowerCase())) {//if name contains the search_string
				searchList.add(userList.get(i));//add into the search array the Shopping
			}
			else if(userList.get(i).isBought()==false && "Not Bought".toLowerCase().contains(search_string.toLowerCase())) {//if name contains the search_string
				searchList.add(userList.get(i));//add into the search array the Shopping
			}
		}
		return searchList;
	}
	
	/**
	 * The user can delete an item
	 * 
	 * @param shopping_to_delete (Shopping)
	 */
	public void deleteShopping(Shopping shopping_to_delete) {
		for (int i=0;i<shoppingList.size();i++) {
			if( shopping_to_delete.equals(shoppingList.get(i))==true){
				shoppingList.remove(i);
				
			}
		}
		
	}
	
	/**
	 * The user can modify the item
	 * 
	 * @param old_shopping (Shopping) represents the old shopping
	 * @param nameofproduct (String) represents the name of the product
	 * @param priceofproduct (double) represents the price of the product
	 * @param typeofproduct (String) represents the type of the product
	 * @param quantityofproduct (int) represents the quantity of the product
	 * @param bought (bolean) represents if the user bought or not bought the product
	 * @param username (String) represents the user that has logged in
	 */
	public void modifyShopping (Shopping old_shopping,String nameofproduct, double priceofproduct, String typeofproduct, int quantityofproduct, boolean bought, String username) {
		System.out.println(old_shopping.toString());
		Shopping shopping_to_modify = new Shopping(nameofproduct, priceofproduct, typeofproduct, quantityofproduct, bought, username);
		for (int i=0;i<shoppingList.size();i++) {
			if( old_shopping.equals(shoppingList.get(i))==true){
				System.out.println(shopping_to_modify.toString());
				shoppingList.set(i, shopping_to_modify);
				
			}
		}
		
	}
	

}
