import java.awt.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;

/**
 * Class represents the main app frame of the app.
 * 
 * Functionalities include:
 * switch_to_register,
 * switch_to_login,
 * switch_to_back,
 * switch_to_back2,
 * login,
 * register,
 * exit,
 * switch_to_add,
 * addItem,
 * modifyItem,
 * search.
 * 
 * @author Elina
 * @version 1.0
 * @company Elina's Company
 * @date 2023-11-23
 *
 */
public class MainAppFrame extends JFrame {
	private ModifyShoppingPanel modify_panel;
	private LoginPanel login_panel;
	private RegisterPanel register_panel;
	private ShoppingPanel shopping_panel;
	private AddShoppingPanel addshopping_panel;
	private UserList usersList = new UserList();
	private ShoppingList shoppingList = new ShoppingList();
	private String shopping_filename="shopping.txt";
	private String users_filename="users.txt";
	private String login_username;
	private int xLoc = 300;
	private int yLoc = 50;

	/**
	 * Constructor that creates the main app (JFrame).
	 */
	public MainAppFrame() {
		super("Super Market");
		setSize(500,300);
		setLocation(xLoc,yLoc);
		usersList.fromFile(users_filename);//load users from file
		shoppingList.fromFile(shopping_filename);//load shopping from file
		
		setLayout(new CardLayout());
		
		login_panel=new LoginPanel();
		add(login_panel);
		
		modify_panel=new ModifyShoppingPanel();
		shopping_panel = new ShoppingPanel(modify_panel,getContentPane());
		add(shopping_panel);
		
		addshopping_panel=new AddShoppingPanel();
		add(addshopping_panel);
		
		
		add(modify_panel);
		
		register_panel=new RegisterPanel();
		add(register_panel);
		
		

		
		
		
		switch_to_register();
		switch_to_login();
		login();
		register();
		exit();
		switch_to_add();
		switch_to_back();
		switch_to_back2();
		addItem();
		modifyItem();
		search();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //otan patithei to koumpi x na kleisei to programma
		setVisible(true); //emfanise to main frame
	}
	
	/**
	 * The button in order to go back to the register
	 */
	public void switch_to_register() {
		login_panel.b_register.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                	CardLayout cardLayout = (CardLayout) (getContentPane().getLayout());
                    cardLayout.next(getContentPane());//go to shopping_panel
                    cardLayout.next(getContentPane());//go to addshopping_panel
                    cardLayout.next(getContentPane());//go to modify_panel
                    cardLayout.next(getContentPane());//go to register_panel
                }
            });
	}
	
	/**
	 * The button in order to go back to the login
	 */
	public void switch_to_login() {
		register_panel.b_login.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                	CardLayout cardLayout = (CardLayout) (getContentPane().getLayout());
                    cardLayout.next(getContentPane());
                }
            });
	}
	
	/**
	 * The button in order to go back from the add shopping panel
	 */
	public void switch_to_back() {
		addshopping_panel.b_back.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                	CardLayout cardLayout = (CardLayout) (getContentPane().getLayout());
                    cardLayout.next(getContentPane());//go to modify_panel
                    cardLayout.next(getContentPane());//go to login_panel
                    cardLayout.next(getContentPane());//go to login_panel
                    cardLayout.next(getContentPane());//go to shopping_panel
                }
            });
	}
	
	/**
	 * The button in order to go back from the modify panel
	 */
	public void switch_to_back2() {
		modify_panel.b_back.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                	CardLayout cardLayout = (CardLayout) (getContentPane().getLayout());
                    cardLayout.next(getContentPane());//go to register_panel
                    cardLayout.next(getContentPane());//go to login_panel
                    cardLayout.next(getContentPane());//go to shopping_panel
                }
            });
	}
	
	/**
	 * The button in order to login
	 */
	public void login() {
		login_panel.b_login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	String username=login_panel.t_username.getText();
            	String password=login_panel.t_password.getText();
            	EnumOfLogin loginenum=usersList.searchByUserNameAndPassword(username, password);
            	if(loginenum==EnumOfLogin.UserFound) {
            		CardLayout cardLayout = (CardLayout) (getContentPane().getLayout());
                    cardLayout.next(getContentPane());
                    login_username=username;
                    shopping_panel.fillDisplayPanel(shoppingList.getShoppingByUsername(login_username),shoppingList,shopping_filename,login_username);//it will show only the user's shopping data that logged in
                    setSize(800,300);
            	}
            	else if(loginenum==EnumOfLogin.WrongUserName) {
            		login_panel.l_message.setText("Username "+username+" doesn't exist !!!");
            		
            	}
            	else {//WrongPassword
            		login_panel.l_message.setText("The password is wrong !!!");
            	}
            }
        });
		
	}
	
	/**
	 * The button in order to register
	 */
	public void register() {
		register_panel.b_register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	String username=register_panel.t_username.getText();
            	String password=register_panel.t_password.getText();
            	String firstname=register_panel.t_firstname.getText();
            	String lastname=register_panel.t_lastname.getText();
            	String email=register_panel.t_email.getText();
            	if(username.equals("")) {
            		register_panel.l_message.setText("You must add a username !!!");
            	}else if (password.equals("")) {
            		register_panel.l_message.setText("You must add a password !!!");
            	}
            	else if (firstname.equals("")) {
            		register_panel.l_message.setText("You must add a first name !!!");
            	}
            	else if (lastname.equals("")) {
            		register_panel.l_message.setText("You must add a last name !!!");
            	}
            	else if (email.equals("")) {
            		register_panel.l_message.setText("You must add an email !!!");
            	}
            	else {
	            	EnumOfLogin loginenum=usersList.searchByUserNameAndPassword(username, password);
					if(loginenum==EnumOfLogin.UserFound || loginenum==EnumOfLogin.WrongPassword) {
					     register_panel.l_message.setText("The user name exists, please enter a new one");	
					 }else {
						 usersList.addUserByData(username, password, firstname, lastname, email);
						 usersList.toFile(users_filename);
						 CardLayout cardLayout = (CardLayout) (getContentPane().getLayout());
		                 cardLayout.next(getContentPane());
		                 login_panel.l_message.setText("Conratulations! You are registered with username "+username+" !");
		                 
					 }
            	}
            }
        });
		
	}
	/**
	 * The button in order to exit
	 */
	public void exit() {
		shopping_panel.b_exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	// Exit the program
                System.exit(0);
            }
        });
		
	}
	
	/**
	 * The button in order to go back to the add button
	 */
	public void switch_to_add() {
		shopping_panel.b_add.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                	CardLayout cardLayout = (CardLayout) (getContentPane().getLayout());
//                	cardLayout.next(getContentPane());
                    cardLayout.next(getContentPane());
                }
            });
	}
	
	/**
	 * The button in order to add item
	 */
	public void addItem() {
		addshopping_panel.b_add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            
            	String nameOfProduct = addshopping_panel.t_nameofproduct.getText();
            	Double priceOfProduct;
            	try{
            		 priceOfProduct = Double.parseDouble(addshopping_panel.t_priceofproduct.getText()) ;
            	}catch(Exception ex) {
            		priceOfProduct=(double) -1;
            	}
            	int quantityOfProduct;
            	try{
            		quantityOfProduct =Integer.parseInt(addshopping_panel.t_quantityofproduct.getText());
	           	}catch(Exception ex) {
	           		quantityOfProduct= -1;
	           	}
            	
            	String typeOfProduct = addshopping_panel.t_typeofproduct.getText();
            	
            	String bought = (String) addshopping_panel.d_bought.getSelectedItem();
            	boolean bought2;
            	if(bought.equals("Bought")) {
            		bought2=true;
            	}
            	else {
            		bought2=false;
            	}
            	
            	if(nameOfProduct.equals("")) {
            		addshopping_panel.l_message.setText("You must add a name for the product !!!");
            	}else if (priceOfProduct==-1) {
            		addshopping_panel.l_message.setText("You must add a price for the product !!!");
            	}
            	else if (typeOfProduct.equals("")) {
            		addshopping_panel.l_message.setText("You must add a type for the product !!!");
            	}
            	else if (quantityOfProduct ==-1) {
            		addshopping_panel.l_message.setText("You must add a quantity for the product !!!");
            	}else {
            		shoppingList.addShoppingByData(nameOfProduct, priceOfProduct, typeOfProduct, quantityOfProduct, bought2, login_username);
                	shoppingList.toFile(shopping_filename);
                	
                	
                	addshopping_panel.t_nameofproduct.setText("");
                	addshopping_panel.t_priceofproduct.setText("");
                	addshopping_panel.t_typeofproduct.setText("");
                	addshopping_panel.t_quantityofproduct.setText("");
                	
                	
                	CardLayout cardLayout = (CardLayout) (getContentPane().getLayout());
                    cardLayout.next(getContentPane());//go to modify_panel
                    cardLayout.next(getContentPane());//go to register_panel
                    cardLayout.next(getContentPane());//go to login_panel
                    cardLayout.next(getContentPane());//go to shopping_panel
                    shopping_panel.fillDisplayPanel(shoppingList.getShoppingByUsername(login_username),shoppingList,shopping_filename,login_username);
            		
            	}
            	
            	
            	
            	
            	
            	
            	
            	
            	
            	
            }
        });
	}
	
	/**
	 * The button in order to modify an item
	 */
	public void modifyItem() {
		modify_panel.b_modify.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            
            	String nameOfProduct = modify_panel.t_nameofproduct.getText();
            	Double priceOfProduct;
            	try{
            		 priceOfProduct = Double.parseDouble(modify_panel.t_priceofproduct.getText()) ;
            	}catch(Exception ex) {
            		priceOfProduct=(double) -1;
            	}
            	int quantityOfProduct;
            	try{
            		quantityOfProduct =Integer.parseInt(modify_panel.t_quantityofproduct.getText());
	           	}catch(Exception ex) {
	           		quantityOfProduct= -1;
	           	}
            	
            	String typeOfProduct = modify_panel.t_typeofproduct.getText();
            	
            	String bought = (String) modify_panel.d_bought.getSelectedItem();
            	boolean bought2;
            	if(bought.equals("Bought")) {
            		bought2=true;
            	}
            	else {
            		bought2=false;
            	}
            	
            	if(nameOfProduct.equals("")) {
            		modify_panel.l_message.setText("You must add a name for the product !!!");
            	}else if (priceOfProduct==-1) {
            		modify_panel.l_message.setText("You must add a price for the product !!!");
            	}
            	else if (typeOfProduct.equals("")) {
            		modify_panel.l_message.setText("You must add a type for the product !!!");
            	}
            	else if (quantityOfProduct ==-1) {
            		modify_panel.l_message.setText("You must add a quantity for the product !!!");
            	}else {
            		shoppingList.modifyShopping(modify_panel.oldShopping,nameOfProduct, quantityOfProduct, typeOfProduct, quantityOfProduct, bought2, login_username);
            		
                	shoppingList.toFile(shopping_filename);
                	
                	modify_panel.t_nameofproduct.setText("");
                	modify_panel.t_priceofproduct.setText("");
                	modify_panel.t_typeofproduct.setText("");
                	modify_panel.t_quantityofproduct.setText("");
                	
                	
                	CardLayout cardLayout = (CardLayout) (getContentPane().getLayout());
                    cardLayout.next(getContentPane());//go to register_panel
                    cardLayout.next(getContentPane());//go to login_panel
                    cardLayout.next(getContentPane());//go to shopping_panel

                    shopping_panel.fillDisplayPanel(shoppingList.getShoppingByUsername(login_username),shoppingList,shopping_filename,login_username);
            		
            	}
            	
            	
            	
            	
            	
            	
            	
            	
            	
            	
            }
        });
	}
	
	/**
	 * The button in order to search items.
	 */
	public void search() {
		shopping_panel.b_search.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	String searchString;
            	searchString = shopping_panel.t_search.getText();
            	
            	ArrayList<Shopping> searchList=shoppingList.search(searchString, login_username);
            	
            	shopping_panel.fillDisplayPanel(searchList,shoppingList,shopping_filename,login_username);
            	
            }
        });
		
	}
}
