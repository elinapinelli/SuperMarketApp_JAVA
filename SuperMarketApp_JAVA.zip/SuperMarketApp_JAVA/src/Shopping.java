import java.util.Objects;

/**
 * Class represents the Shoppings of the app.
 * 
 * @author Elina
 * @version 1.0
 * @company Elina's Company
 * @date 2023-11-05
 *
 */
public class Shopping {
	private String nameofproduct;
	private double priceofproduct;
	private String typeofproduct;
	private int quantityofproduct;
	private boolean bought;
	private String username;

	/**
	 * Constructor that creates an shopping item.
	 * 
	 * @param nameofproduct (String) represents the name of one product
	 * @param priceofproduct (double) represents the price of one product
	 * @param typeofproduct (String) represents the name of one product
	 * @param quantityofproduct (int) represents the quantity of one product
	 * @param bought (boolean) represents if the user has bought or not bought the item
	 * @param username (String) represents each user that have logged in
	 */
	public Shopping(String nameofproduct, double priceofproduct, String typeofproduct, int quantityofproduct,
			boolean bought, String username) {
		this.nameofproduct = nameofproduct;
		this.priceofproduct = priceofproduct;
		this.typeofproduct = typeofproduct;
		this.quantityofproduct = quantityofproduct;
		this.bought = bought;
		this.username = username;
	}

	/**
	 * Second constructor that creates a shopping item from file string.
	 * 
	 * @param shoppingInfo (String) represents shopping from a file eg. shoppingInfo="patatakia,3.5,fagosimo,2,true,el".
	 */
	public Shopping(String shoppingInfo) {//eg. shoppingInfo="patatakia,3.5,fagosimo,2,true,el"
		String[] shoppingData= shoppingInfo.split(",");//gets ann array of String
		this.nameofproduct = shoppingData[0];
		this.priceofproduct = Double.parseDouble(shoppingData[1]);
		this.typeofproduct = shoppingData[2];
		this.quantityofproduct = Integer.parseInt(shoppingData[3]);
		this.bought = Boolean.parseBoolean(shoppingData[4]);
		this.username = shoppingData[5];
	}
	
	
	public String getNameofproduct() {
		return nameofproduct;
	}

	public void setNameofproduct(String nameofproduct) {
		this.nameofproduct = nameofproduct;
	}

	public double getPriceofproduct() {
		return priceofproduct;
	}

	public void setPriceofproduct(double priceofproduct) {
		this.priceofproduct = priceofproduct;
	}

	public String getTypeofproduct() {
		return typeofproduct;
	}

	public void setTypeofproduct(String typeofproduct) {
		this.typeofproduct = typeofproduct;
	}

	public int getQuantityofproduct() {
		return quantityofproduct;
	}

	public void setQuantityofproduct(int quantityofproduct) {
		this.quantityofproduct = quantityofproduct;
	}

	public boolean isBought() {
		return bought;
	}

	public void setBought(boolean bought) {
		this.bought = bought;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String toString() {
		return nameofproduct + "," + priceofproduct + "," +  typeofproduct + "," + quantityofproduct + "," + bought + "," + username;
	}
	
	/**
	 * Calculates the cost of the product(multiplication the price of quantity
	 * @return (double) the cost of shopping
	 */
	double get_cost() {
		double cost=priceofproduct*quantityofproduct;
		return cost;
	}
	
	
	

	@Override
	/**
	 * Autocreated function that convert a shopping to a Hash and it is used automatically in equals function.
	 */
	public int hashCode() {
		return Objects.hash(bought, nameofproduct, priceofproduct, quantityofproduct, typeofproduct, username);
	}

	@Override
	/**
	 * Autocreated function that checks if two shoppings are equal.
	 * @param obj (Shopping) represents the shopping that checks if it is equals.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Shopping other = (Shopping) obj;
		return bought == other.bought && Objects.equals(nameofproduct, other.nameofproduct)
				&& Double.doubleToLongBits(priceofproduct) == Double.doubleToLongBits(other.priceofproduct)
				&& quantityofproduct == other.quantityofproduct && Objects.equals(typeofproduct, other.typeofproduct)
				&& Objects.equals(username, other.username);
	}
	
	
}
