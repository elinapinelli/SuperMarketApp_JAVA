/**
 * Class represents the users of the app.
 * 
 * @author Elina
 * @version 1.0
 * @company Elina's Company
 * @date 2023-11-25
 *
 */
public class User {
	private String userName;
	private String password;
	private String firstName;
	private String lastName;
	private String email;
	
	/**
	 *  Constructor that creates a user from data.
	 *  
	 * @param userName (String) represents the user name of the user
	 * @param password (String) represents the password of the user
	 * @param firstName (String) represents the first name of the user
	 * @param lastName (String) represents the last name of the user
	 * @param email (String) represents the email of the user
	 */
	public User(String userName, String password, String firstName, String lastName, String email) {
		
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}
	
	/**
	 * Second costructor  that creates a user from a string eg. userInfo="elina3,3,Elina,Pinelli,el@gmail.com".
	 * 
	 * @param userInfo (String)
	 */
	public User(String userInfo) {//eg. userInfo="elina3,3,Elina,Pinelli,el@gmail.com"
		String[] userData=userInfo.split(",");//gets ann array of String
		this.userName = userData[0];
		this.password = userData[1];
		this.firstName = userData[2];
		this.lastName = userData[3];
		this.email =userData[4];
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return userName + "," + password + "," + firstName + "," + lastName + "," + email;
	}
	
	

}
